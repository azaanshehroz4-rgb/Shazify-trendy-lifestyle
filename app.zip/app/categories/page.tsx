import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Link from "next/link";
import { db } from "../lib/firebase";
import { collection, getDocs } from "firebase/firestore";



export default async function CategoriesPage() {
  const snapshot = await getDocs(collection(db, "products"));

const products: any[] = snapshot.docs.map((doc) => ({
  id: doc.id,
  ...doc.data(),
}));

const categoriesMap = new Map<string, string>();

products.forEach((product) => {
  const category = product.category?.trim();

  if (!category) return;

  const normalizedCategory = category.toLowerCase();

  if (!categoriesMap.has(normalizedCategory)) {
    categoriesMap.set(normalizedCategory, category);
  }
});

const categories = Array.from(categoriesMap.values());
  return (
    <>
      <Navbar />

      <div className="max-w-7xl mx-auto py-16 px-6">

        <h1 className="text-5xl font-bold text-center mb-12">
          Shop by Categories
        </h1>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">

          {categories.map((category) => (
            <Link
              key={category}
              href={`/category/${category}`}
              className="bg-pink-600 text-white rounded-2xl p-10 text-center text-2xl font-bold hover:bg-pink-700 transition"
            >
              {category}
            </Link>
          ))}

        </div>

      </div>

      <Footer />
    </>
  );
}